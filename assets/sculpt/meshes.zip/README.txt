ARQUIPELAGO DAS FERAS - 30 adult DCC meshes

These GLBs reconstruct the actual native runtime part geometry.
They preserve feature names and material colors, with Y-up glTF coordinates.
They are not uploaded Roblox MeshParts or skinned/animated GLB rigs.
The game uses the matching ModelFactory assemblies with Motor6D rigs.
rig-map.json documents the native joint connections and C0 matrices.
Generate with scripts/sculpt/render_models.py; no asset IDs are invented.
